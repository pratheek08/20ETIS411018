import "./App.css";

import Auth from "./components/Auth";

function App() {
  return (
    <div>
      <Auth />
    </div>
  );
}

export default App;
